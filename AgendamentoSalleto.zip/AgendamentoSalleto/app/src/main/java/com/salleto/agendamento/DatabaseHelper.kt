package com.salleto.agendamento

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "agendamentos.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "agendamentos"
        private const val COLUMN_ID = "id"
        private const val COLUMN_TIPO = "tipo"
        private const val COLUMN_DATA = "data"
        private const val COLUMN_HORA = "hora"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = """
            CREATE TABLE $TABLE_NAME (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, 
                $COLUMN_TIPO TEXT, 
                $COLUMN_DATA TEXT, 
                $COLUMN_HORA TEXT
            )
        """.trimIndent()
        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun addAgendamento(tipo: String, data: String, hora: String, context: Context): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_TIPO, tipo)
            put(COLUMN_DATA, data)
            put(COLUMN_HORA, hora)
        }
        val result = db.insert(TABLE_NAME, null, values)
        db.close()

        if (result != -1L) {
            salvarAgendamentoEmTxt(context, tipo, data, hora)
        }

        return result != -1L
    }

    fun getAgendamentos(): MutableList<Agendamento> {
        val agendamentos = mutableListOf<Agendamento>()
        val db = this.readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_NAME", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
                val tipo = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIPO))
                val data = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATA))
                val hora = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_HORA))

                agendamentos.add(Agendamento(id, tipo, data, hora))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return agendamentos
    }

    private fun salvarAgendamentoEmTxt(context: Context, tipo: String, data: String, hora: String) {
        val fileName = "agendamentos.txt"
        val file = File(context.filesDir, fileName)

        try {
            val fos = FileOutputStream(file, true) // true para adicionar sem sobrescrever
            val writer = OutputStreamWriter(fos)
            writer.write("$tipo, $data, $hora\n")
            writer.close()
            fos.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
