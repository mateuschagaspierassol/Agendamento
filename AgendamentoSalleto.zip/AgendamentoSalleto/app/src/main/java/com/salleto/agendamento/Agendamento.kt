package com.salleto.agendamento

// Data class Agendamento
data class Agendamento(
    val id: Int,
    val tipo: String,
    val data: String,
    val hora: String
)
