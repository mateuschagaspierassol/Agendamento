package com.salleto.agendamento

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var listViewAgendamentos: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var databaseHelper: DatabaseHelper
    private var agendamentos: MutableList<Agendamento> = mutableListOf()
    private lateinit var edtData: EditText
    private lateinit var edtHora: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listViewAgendamentos = findViewById(R.id.listViewAgendamentos)
        val btnSalvar = findViewById<Button>(R.id.btnSalvar)
        val edtTipo = findViewById<EditText>(R.id.edtTipo)
        edtData = findViewById(R.id.edtData)
        edtHora = findViewById(R.id.edtHora)

        databaseHelper = DatabaseHelper(this)

        carregarAgendamentos()

        // Configurar o DatePickerDialog
        edtData.setOnClickListener {
            val calendario = Calendar.getInstance()
            val ano = calendario.get(Calendar.YEAR)
            val mes = calendario.get(Calendar.MONTH)
            val dia = calendario.get(Calendar.DAY_OF_MONTH)

            val datePicker = DatePickerDialog(this, { _, year, month, dayOfMonth ->
                val formato = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val dataSelecionada = Calendar.getInstance()
                dataSelecionada.set(year, month, dayOfMonth)
                edtData.setText(formato.format(dataSelecionada.time))
            }, ano, mes, dia)

            datePicker.show()
        }

        // Configurar o TimePickerDialog
        edtHora.setOnClickListener {
            val calendario = Calendar.getInstance()
            val hora = calendario.get(Calendar.HOUR_OF_DAY)
            val minuto = calendario.get(Calendar.MINUTE)

            val timePicker = TimePickerDialog(this, { _, hourOfDay, minute ->
                edtHora.setText(String.format("%02d:%02d", hourOfDay, minute))
            }, hora, minuto, true)

            timePicker.show()
        }

        btnSalvar.setOnClickListener {
            val tipo = edtTipo.text.toString().trim()
            val data = edtData.text.toString().trim()
            val hora = edtHora.text.toString().trim()

            if (tipo.isNotEmpty() && data.isNotEmpty() && hora.isNotEmpty()) {
                val sucesso = databaseHelper.addAgendamento(tipo, data, hora, this)
                if (sucesso) {
                    Toast.makeText(this, "Agendamento concluído!", Toast.LENGTH_LONG).show()
                    carregarAgendamentos()
                    edtTipo.text.clear()
                    edtData.text.clear()
                    edtHora.text.clear()
                } else {
                    Toast.makeText(this, "Erro ao agendar", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun carregarAgendamentos() {
        agendamentos = databaseHelper.getAgendamentos()
        val listaStrings = agendamentos.map { "${it.tipo} - ${it.data} ${it.hora}" }

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listaStrings)
        listViewAgendamentos.adapter = adapter
    }
}
